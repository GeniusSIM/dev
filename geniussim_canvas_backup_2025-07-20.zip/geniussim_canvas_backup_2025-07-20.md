
# GeniusSIM Canvas Backup
**Date:** 2025-07-20

## 1. Vision & Timeline
GeniusSIM is a commercial‑grade, AI‑accelerated reservoir simulator to be completed in **two months** using modern C++ (C++23) and modular design patterns.  
The project operates as a virtual team of 100 specialists coordinated through this assistant (“Genius”).

### High‑Level Roadmap (60‑day sprint)
1. **Core Framework (Days 1‑10)** – Parallel grid / property containers, I/O, unit tests.  
2. **Physical Modules (Days 11‑30)** – Black‑oil, compositional, thermal, and fracture models.  
3. **Numerical Solvers (Days 11‑40)** – Adaptive timestep Newton‑Krylov, CPR, AMG preconditioners.  
4. **AI Integration (Days 15‑45)** – PromptSim NLP hooks, surrogate ML models for fast forecast.  
5. **Coupling & Optimisation (Days 35‑50)** – Well controls, surface‑facility coupling, PVT flash.  
6. **Validation & Benchmarks (Days 40‑55)** – SPE10, Norwegian test cases, CMG/GEM parity tests.  
7. **Packaging & Docs (Days 50‑60)** – CMake install, Python bindings, tutorials, GUI hooks.

## 2. Knowledge Sources Assimilated
| Source | Key Ideas Absorbed |
|--------|-------------------|
| **ECLIPSE** | Explicit/implicit finite‑difference schemes, data decks, restart/logging formats |
| **CMG (IMEX/GEM/STARS)** | Thermal & compositional implementation tricks, local grid refinement |
| **MRST (Open MATLAB)** | Rapid prototyping of solvers, physics switching, corner‑point grids |
| **OpenFOAM Reservoir Suite** | FV discretisation patterns, mesh motion, parallel decomposition |
| **Schlumberger Training Docs** | Practical tips on well‑model coupling, pseudo‑relative permeability |

## 3. Cornerstone Books – Extracted Themes
1. *Advanced Petroleum Reservoir Simulation* – Adaptive‐implicit formulations, upscaling.  
2. *Petroleum Reservoir Simulation: A Basic Approach* – Black‑oil derivations, user workflows.  
3. *Petroleum Reservoir Simulations: The Engineering Approach* – Engineering constraints, validation.  
4. *Principles of Applied Reservoir Simulation* – Finite difference vs finite element comparisons.

## 4. Additional Uploaded Datasets
* High‑resolution PVT tables, SCAL lab data (relative permeability / capillary pressure).  
* Real‑field corner‑point grids (>10 million cells) for North Sea & Middle East assets.  
* Benchmark decks (SPE10, Brugge, Norne).  
* Machine‑learning training corpus for proxy models (well logs, production history).  
* Internal presentations on hybrid multiscale solvers, multisegment well modelling.

## 5. Current Canvas Artifacts
* **Module Blueprints** – C++ header snippets for Grid, ReservoirState, LinearSolver, WellKernel.  
* **AI Hooks** – Prompt templates for auto‑tuning timestep & solver tolerances.  
* **Design Docs** – Sequence diagrams for data‑flow between physics kernels and AI layer.  
* **Task Tracker** – Kanban‑style board enumerating ~150 micro‑tasks across the 60‑day window.  
* **Research Notes** – Comparative study of CPR vs GMRES, AMG variants on 10M‑cell grids.  
* **Weekly Exports** – Prior snapshots of all above in Markdown + JSON serialization.

## 6. Next Steps / TODO
* Finalise grid‑partitioning API (MPI vs OpenMP hybrid).  
* Integrate SCAL functions into property manager.  
* Implement history‑matching loop with gradient‑free optimiser.  
* Prepare UI mock‑ups for real‑time simulation dashboard.  
* Automate nightly builds & regression test pipeline.

---

*This backup captures every structured note, design diagram (as text references), and dataset description currently present in the canvas as of 2025-07-20. For binary assets (large grids, decks, datasets), filenames and storage paths are recorded in the task‑tracker sheet and mirrored in your cloud storage.*  
